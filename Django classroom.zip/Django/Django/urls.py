"""
URL configuration for Django project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from appli.views import * 
from Django import settings
from django.conf.urls.static import static 

urlpatterns = [
    path('admin/', admin.site.urls),
    path("login", u_login, name="login"),
    path("signup",u_signup,name="signup"),
    path("",acceuil,name="acceuil"),
    path("student_home",student_home,name="student_home"),
    path("teacher_home",teacher_home,name="teacher_home"),
    path("entreprise_home",entreprise_home,name="entreprise_home"),
    path("student_post",student_post,name="student_post"),
    path("student_cv",student_cv,name="student_cv"),
    path("student_chat",student_chat,name="student_chat"),
    path("student_chat_f/<int:friend_id>/",student_chat_f,name="student_chat_f"),
    path("student_become_f",student_become_f,name="student_become_f"),
    path("add_new_friend",add_new_friend,name="add_new_friend"),
    path("create_friend/<int:friend_id>/",create_friend,name="create_friend"),
    path("student_setting",student_setting,name="student_setting"),
    path("entreprise_home",entreprise_home,name="entreprise_home"),
    path("entreprise_post",entreprise_post,name="entreprise_post"),
    path("entreprise_setting",entreprise_setting,name="entreprise_setting"),
    path("entreprise_chat",entreprise_chat,name="entreprise_chat"),
    path("entreprise_chat_f/<int:friend_id>/",entreprise_chat_f,name="entreprise_chat_f"),
    path("entreprise_become_f",entreprise_become_f,name="entreprise_become_f"),
    path("teacher_home",teacher_home,name="teacher_home"),
    path("teacher_cv",teacher_cv,name="teacher_cv"),
    path("teacher_setting",teacher_setting,name="teacher_setting"),
    path("teacher_chat",teacher_chat,name="teacher_chat"),
    path("teacher_chat_f/<int:friend_id>/",teacher_chat_f,name="teacher_chat_f"),
    path("teacher_become_f",teacher_become_f,name="teacher_become_f"),
    path("teacher_classroom",teacher_classroom,name="teacher_classroom"),
    path('save_comment/<int:cour_id>/', save_comment, name='save_comment'),
    path("add_student",add_student,name="add_student"),
    path("cour_post",cour_post,name="cour_post"),
    path("student_classroom",student_classroom,name="student_classroom")

    

]+   static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

