from django.db import models
from django.contrib.auth.models import AbstractUser

class Utilisateur(AbstractUser):
    fullname = models.CharField(max_length=100)
    accounttype = models.IntegerField(default=0)
    avatar = models.ImageField(upload_to='avatar_pictures/', default='avatar0.png')
    bio = models.CharField(max_length=400)
    private = models.BooleanField(default=False)
    

class Post(models.Model):
    user = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField()
    image = models.ImageField(upload_to='post_images/', default='post_images.jpg')    

class Chat(models.Model):
    user = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='chats_sent')
    friend = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='chats_received')
    content = models.CharField(max_length=400)

class Friend(models.Model):
    user = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='user_friends')
    friend = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='friend_users')
    
class BecomeFriend(models.Model):
    user = models.ForeignKey(Utilisateur, related_name='user_become_friend', on_delete=models.CASCADE)
    friend = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)


class PostCour(models.Model):
    prof = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='user_post_cours')
    content = models.TextField()

class Comment(models.Model):
    user = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='user_comments')
    content = models.TextField()
    cour = models.ForeignKey(PostCour, on_delete=models.CASCADE, related_name='comments')
   

class Classroom(models.Model):
    prof = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='prof_classrooms')
    student = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='student_classrooms')






