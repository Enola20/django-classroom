from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .models import *
from django.db.models import Q
from django.shortcuts import redirect, get_object_or_404

from django.contrib import messages

# Create your views here.

def acceuil(request):
    return render(request,"Acceuil/index.html",{})

def u_login(request):
    if request.method == 'POST':
        # Récupérer les données du formulaire
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authentifier l'utilisateur
        user = authenticate(request, username=username, password=password)

        # Vérifier si l'authentification a réussi
        if user is not None:
            # Connecter l'utilisateur
            login(request, user)
            # Rediriger vers une page de succès ou une page d'accueil
            if user.accounttype == 0:
                # Rediriger l'étudiant vers une page spécifique pour les étudiants
                return redirect("student_home")
            elif user.accounttype == 1:
                # Rediriger le professeur vers une page spécifique pour les professeurs
                return redirect("teacher_home")
            elif user.accounttype == 2:
                # Rediriger l'entreprise vers une page spécifique pour les entreprises
                return redirect("entreprise_home")
        else:
            # Si l'authentification échoue, retourner le formulaire de connexion avec un message d'erreur
            return render(request, 'Acceuil/error.html', {'error': 'Invalid username or password'})

    # Si la méthode de la requête n'est pas POST, retourner simplement le formulaire de connexion
    return render(request, 'Acceuil/login.html', {})

def entreprise_home(request):
    user = request.user
    posts = Post.objects.all().order_by("-id")
    return render(request,'Entreprise/index.html',{"user" : user,"posts" : posts}) 

def u_signup(request):
    if request.method == 'POST':
        # Récupérer les données du formulaire
        fullname = request.POST.get('fullmane')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        accounttype = request.POST.get('accounttype')
        if Utilisateur.objects.filter(Q(email=email) | Q(username=username)).exists():
            return render(request, 'Acceuil/error.html', {'error': 'Email or  username already exist'})


        # Créer un nouvel utilisateur
        user = Utilisateur.objects.create_user(
            username=username,
            email=email,
            password=password,
            fullname=fullname,
            accounttype=accounttype
        )

        # Authentifier et connecter l'utilisateur nouvellement créé
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            # Rediriger vers une page de succès ou une page d'accueil
            if user.accounttype == 0:
                # Rediriger l'étudiant vers une page spécifique pour les étudiants
                return redirect("student_home")
            elif user.accounttype == 1:
                # Rediriger le professeur vers une page spécifique pour les professeurs
                return redirect("teacher_home")
            elif user.accounttype == 2:
                # Rediriger l'entreprise vers une page spécifique pour les entreprises
                return redirect("entreprise_home")

    # Si la méthode de la requête n'est pas POST ou si l'inscription n'a pas réussi, 
    # retourner simplement le formulaire d'inscription vide
    return render(request, "Acceuil/signup.html", {})


def student_home(request):
    user = request.user
    posts = Post.objects.all().order_by("-id")
    return render(request,'Student/index.html',{"user" : user,"posts" : posts})

def teacher_home(request):
    return render(request,'Teacher/index.html',{})



def student_post(request):
    if request.method == "POST":
        content = request.POST.get('user_bio')  # Utilisez 'user_bio' pour récupérer le contenu du post
        image = request.FILES.get('profile_pic')  # Utilisez 'profile_pic' pour récupérer l'image du post
        
        # Enregistrez le post dans la base de données
        post = Post(content=content, image=image, user=request.user)  # Assurez-vous que request.user contient l'utilisateur connecté
        post.save()
        
        # Rediriger vers une page de confirmation ou une autre page
        return redirect('student_home')  # Remplacez 'confirmation_page' par le nom de votre page de confirmation
        
    return render(request, "Student/student_post.html")


def student_cv(request):
        if request.method == "POST":
            content = request.POST.get('content')  # Utilisez 'user_bio' pour récupérer le contenu du post
            image = request.FILES.get('image')  # Utilisez 'profile_pic' pour récupérer l'image du post
            
            # Enregistrez le post dans la base de données
            post = Post(content=content, image=image, user=request.user)  # Assurez-vous que request.user contient l'utilisateur connecté
            post.save()
            
            # Rediriger vers une page de confirmation ou une autre page
            return redirect('student_home')
        user = request.user
        posts = Post.objects.all().order_by("-id")
        return render(request,'Student/student_cv.html',{"user" : user,"posts" : posts})


def student_chat(request):

        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    

    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Student/student_chat.html", { "user": request.user,  "relations": elts})

def student_chat_f(request, friend_id):
    if request.method == "POST":
        friend = Utilisateur.objects.get(id=friend_id)
        content = request.POST.get("content")  # Utilisez get pour éviter les erreurs si la clé n'existe pas
        newchat = Chat.objects.create(content=content, user=request.user, friend=friend)
        
 
        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    
    friend = Utilisateur.objects.get(id=friend_id)
    chats = Chat.objects.filter(Q(user=request.user, friend=friend) | Q(user=friend, friend=request.user)).order_by('id')
    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Student/student_chat_f.html", {"chats": chats, "user": request.user, "friend": friend, "relations": elts})


def student_become_f(request):
    friendB = BecomeFriend.objects.filter(friend=request.user)  
    return render(request,"Student/student_become_friend.html",{"friendB":friendB})


def add_new_friend(request):
    if request.method == "POST":
        username = request.POST.get("username")
        friendB = BecomeFriend.objects.filter(friend=request.user) 
        friend = Utilisateur.objects.get(username=username)
        if BecomeFriend.objects.filter(Q(user=request.user, friend=friend) | Q(friend=request.user, user=friend)).exists():
                    if request.user.accounttype == 0:
                        return render(request,"Student/student_become_friend.html",{"friendB" :friendB})
                    elif request.user.accounttype == 1 :
                        return render(request,"Teacher/teacher_become_friend.html",{"friendB" :friendB})
                    else:
                        return render(request,"Entreprise/entreprise_become_friend.html",{"friendB" :friendB})

        if Friend.objects.filter(Q(user=request.user, friend=friend) | Q(friend=request.user, user=friend)).exists():
                if request.user.accounttype == 0:
                    return render(request,"Student/student_become_friend.html",{"friendB" :friendB})
                elif request.user.accounttype == 1 :
                    return render(request,"Teacher/teacher_become_friend.html",{"friendB" :friendB})
                else:
                    return render(request,"Entreprise/entreprise_become_friend.html",{"friendB" :friendB})
        newconnexion = BecomeFriend.objects.create(user=request.user, friend=friend)
        newconnexion.save()
        

    if request.user.accounttype == 0:
        return render(request,"Student/student_become_friend.html",{"friendB" :friendB})
    elif request.user.accounttype == 1 :
        return render(request,"Teacher/teacher_become_friend.html",{"friendB" :friendB})
    else:
        return render(request,"Entreprise/entreprise_become_friend.html",{"friendB" :friendB})


def create_friend(request,friend_id):

        friend = Utilisateur.objects.get(id=friend_id)
        if BecomeFriend.objects.filter(Q(user=request.user, friend=friend) | Q(friend=request.user, user=friend)).exists():
            newrelation = Friend.objects.create(user=request.user, friend=friend)
            newrelation.save()
            supprimer = BecomeFriend.objects.filter(Q(user=request.user, friend=friend) | Q(friend=request.user, user=friend)).first()
        if supprimer:
            supprimer.delete()
        friendB = BecomeFriend.objects.filter(friend=request.user) 
        if request.user.accounttype == 0:
         return render(request,"Student/student_become_friend.html",{"friendB" :friendB})
        elif request.user.accounttype == 1:
            return render(request,"Teacher/teacher_become_friend.html",{"friendB" :friendB})
        else:
            return render(request,"Entreprise/entreprise_become_friend.html",{"friendB" :friendB})


# views.py


def student_setting(request):
    if request.method == 'POST':
        fullname = request.POST.get('fullname')
        about = request.POST.get('about')
        avatar = request.FILES.get('avatar')
        
        # Update user information
        user = request.user
        user.fullname = fullname
        user.bio = about
        if avatar:
            user.avatar = avatar
        user.save()
        
        messages.success(request, 'Your settings have been updated successfully.')
    
    return render(request, "Student/student_settings.html", {})




def entreprise_post(request):
    if request.method == "POST":
        content = request.POST.get('user_bio')  # Utilisez 'user_bio' pour récupérer le contenu du post
        image = request.FILES.get('profile_pic')  # Utilisez 'profile_pic' pour récupérer l'image du post
        
        # Enregistrez le post dans la base de données
        post = Post(content=content, image=image, user=request.user)  # Assurez-vous que request.user contient l'utilisateur connecté
        post.save()
        
        # Rediriger vers une page de confirmation ou une autre page
        return redirect('student_home')  # Remplacez 'confirmation_page' par le nom de votre page de confirmation
        
    return render(request, "Entreprise/entreprise_post.html")


def entreprise_setting(request):
    if request.method == 'POST':
        fullname = request.POST.get('fullname')
        about = request.POST.get('about')
        avatar = request.FILES.get('avatar')
        
        # Update user information
        user = request.user
        user.fullname = fullname
        user.bio = about
        if avatar:
            user.avatar = avatar
        user.save()
        
        messages.success(request, 'Your settings have been updated successfully.')
    
    return render(request, "Entreprise/entreprise_setting.html", {})


def entreprise_chat(request):

        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    

    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Entreprise/entreprise_chat.html", { "user": request.user,  "relations": elts})




def entreprise_chat_f(request, friend_id):
    if request.method == "POST":
        friend = Utilisateur.objects.get(id=friend_id)
        content = request.POST.get("content")  # Utilisez get pour éviter les erreurs si la clé n'existe pas
        newchat = Chat.objects.create(content=content, user=request.user, friend=friend)
        
 
        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    
    friend = Utilisateur.objects.get(id=friend_id)
    chats = Chat.objects.filter(Q(user=request.user, friend=friend) | Q(user=friend, friend=request.user)).order_by('id')
    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Entreprise/entreprise_chat_f.html", {"chats": chats, "user": request.user, "friend": friend, "relations": elts})


def entreprise_become_f(request):
    friendB = BecomeFriend.objects.filter(friend=request.user)

    
    return render(request,"Entreprise/entreprise_become_friend.html",{"friendB":friendB})

def teacher_home(request):
    user = request.user
    posts = Post.objects.all().order_by("-id")
    return render(request,'Teacher/index.html',{"user" : user,"posts" : posts}) 




def teacher_cv(request):
        if request.method == "POST":
            content = request.POST.get('content')  # Utilisez 'user_bio' pour récupérer le contenu du post
            image = request.FILES.get('image')  # Utilisez 'profile_pic' pour récupérer l'image du post
            
            # Enregistrez le post dans la base de données
            post = Post(content=content, image=image, user=request.user)  # Assurez-vous que request.user contient l'utilisateur connecté
            post.save()
            
            # Rediriger vers une page de confirmation ou une autre page
            return redirect('teacher_home')
        user = request.user
        posts = Post.objects.all().order_by("-id")
        return render(request,'Teacher/teacher_cv.html',{"user" : user,"posts" : posts})



def teacher_setting(request):
    if request.method == 'POST':
        fullname = request.POST.get('fullname')
        about = request.POST.get('about')
        avatar = request.FILES.get('avatar')
        
        # Update user information
        user = request.user
        user.fullname = fullname
        user.bio = about
        if avatar:
            user.avatar = avatar
        user.save()
        
        messages.success(request, 'Your settings have been updated successfully.')
    
    return render(request, "Teacher/teacher_setting.html", {})


def teacher_chat(request):

        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    

    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Teacher/teacher_chat.html", { "user": request.user,  "relations": elts})




def teacher_chat_f(request, friend_id):
    if request.method == "POST":
        friend = Utilisateur.objects.get(id=friend_id)
        content = request.POST.get("content")  # Utilisez get pour éviter les erreurs si la clé n'existe pas
        newchat = Chat.objects.create(content=content, user=request.user, friend=friend)
        
 
        # Pas besoin de sauvegarder à nouveau, create le fait déjà
    
    friend = Utilisateur.objects.get(id=friend_id)
    chats = Chat.objects.filter(Q(user=request.user, friend=friend) | Q(user=friend, friend=request.user)).order_by('id')
    relation = Friend.objects.filter(Q(user=request.user) | Q(friend=request.user))
    
    # Créez une liste pour stocker les utilisateurs des réseaux
    elts = []

    # Parcourez les réseaux et ajoutez les utilisateurs à la liste superreseaux
    for reseau in relation:
        # Ajoutez l'utilisateur au superreseaux si l'utilisateur est différent de l'utilisateur actuel
        if reseau.user != request.user:
            elts.append(reseau.user)
        # Ajoutez la relation au superreseaux si la relation est différente de l'utilisateur actuel
        if reseau.friend != request.user:
            elts.append(reseau.friend)
               
    return render(request, "Teacher/teacher_chat_f.html", {"chats": chats, "user": request.user, "friend": friend, "relations": elts})



def teacher_become_f(request):
    friendB = BecomeFriend.objects.filter(friend=request.user)

    
    return render(request,"Teacher/teacher_become_friend.html",{"friendB":friendB})


 




 

 

 

def teacher_classroom(request):
    """
    Retrieves all posts associated with the current user,
    their associated comments, and the students associated with the professor,
    and renders the course list template.
    """
    # Récupérer tous les posts associés au professeur actuel
    posts = PostCour.objects.filter(prof=request.user).prefetch_related('comments__user').all().order_by("-id")

    # Récupérer tous les étudiants associés au professeur actuel
    students = Classroom.objects.filter(prof=request.user).select_related('student').all()

    context = {'posts': posts, 'students': students}
    return render(request, 'Teacher/teacher_classroom.html', context)


 

def student_classroom(request):
    """
    Retrieves all posts associated with the current user,
    and renders the course list template for students.
    """
    # Récupérer l'utilisateur actuel
    current_user = request.user

    # Récupérer le premier enregistrement de la classe Classroom associé à l'utilisateur actuel (étudiant)
    classroom = Classroom.objects.filter(student=current_user).first()

    # Vérifier si la classe a été trouvée
    if classroom:
        # Récupérer le professeur associé à la classe
        prof = classroom.prof
        students = Classroom.objects.filter(prof=prof).select_related('student').all()

        # Récupérer tous les posts associés au professeur trouvé
        posts = PostCour.objects.filter(prof=prof).prefetch_related('comments__user').order_by("-id")

        context = {'posts': posts ,'students': students}
        return render(request, 'Student/student_classroom.html', context)
    else:
        # Si aucune classe n'est associée à l'utilisateur, renvoyer un contexte vide
        context = {'posts': []}
        return render(request, 'Student/student_classroom.html', context)



 
 

def save_comment(request, cour_id):
    """
    Saves a new comment for a given course.
    """
    post_cour = get_object_or_404(PostCour, pk=cour_id)
    comment_text = request.POST['comment']
    user = request.user

    # Créer un nouveau commentaire
    comment = Comment.objects.create(
        content=comment_text,
        user=user,
        cour=post_cour,
    )

    # Rediriger vers la page de détail du cours après l'enregistrement réussi
    if request.user.accounttype == 0:
        return redirect('student_classroom')
    else :
        return redirect('teacher_classroom')







def cour_post(request):
    """
    View to save a post from the professor in the database.
    """
    if request.method == 'POST':
        content = request.POST.get('content')  # Récupérer le contenu du post à partir des données POST
        # Créer un nouveau post associé au professeur actuel
        post = PostCour.objects.create(prof=request.user, content=content)
        return redirect("teacher_classroom")
    else:
        return render(request,"Teacher/cour_post.html",{})
    

def add_student(request):
    """
    View to add a student associated with the professor in the database.
    """
    if request.method == 'POST':
        username = request.POST.get('username')  # Récupérer le nom d'utilisateur de l'étudiant depuis les données POST
        # Rechercher l'utilisateur correspondant dans la base de données
        try:
            student = Utilisateur.objects.get(username=username)
        except Utilisateur.DoesNotExist:
            return JsonResponse({'error': 'Student with this username does not exist'}, status=400)
        # Créer une relation entre le professeur actuel et l'étudiant
        Classroom.objects.create(prof=request.user, student=student)
        return redirect("teacher_classroom")
    else:
        return render(request,"Teacher/add_student.html",{})



